package com.rajesh.json;

public class ProductVO {
	private String itemid;
	private String productname;
	private double listprice;
	private double unitcost;
	private String attr1;
	private String status;
	private String productid;
	
	
	public ProductVO(String itemid, String productname, double listprice, double unitcost, String attr1, String status,
			String productid) {
		super();
		this.itemid = itemid;
		this.productname = productname;
		this.listprice = listprice;
		this.unitcost = unitcost;
		this.attr1 = attr1;
		this.status = status;
		this.productid = productid;
	}

	public String getItemid() {
		return itemid;
	}

	public void setItemid(String itemid) {
		this.itemid = itemid;
	}

	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public double getListprice() {
		return listprice;
	}
	public void setListprice(double listprice) {
		this.listprice = listprice;
	}
	public double getUnitcost() {
		return unitcost;
	}
	public void setUnitcost(double unitcost) {
		this.unitcost = unitcost;
	}
	public String getAttr1() {
		return attr1;
	}
	public void setAttr1(String attr1) {
		this.attr1 = attr1;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getProductid() {
		return productid;
	}

	public void setProductid(String productid) {
		this.productid = productid;
	}
	
}
