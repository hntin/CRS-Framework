package com.rajesh.json;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rajesh.json.Report;

import com.opensymphony.xwork2.ActionSupport;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class ReadJSON extends ActionSupport {

	private static final long serialVersionUID = -6765991741441442190L;

	private List<Report> data;
	private List<ComboBoxData> cbxArray;
	private String rows;
	private String page;
	private List<ProductVO> rowList;
	private Map<String , Object> session;
	private Map<String , Object> responseJson;
	private JSONObject result;
	
	public class ComboBoxData{
		private int id;
		private String text;
		private String selected;
		private int status;
		
		
		public ComboBoxData(int id, String text, String selected, int status) {
			super();
			this.id = id;
			this.text = text;
			this.selected = selected;
			this.status = status;
		}
		
		public int getStatus() {
			return status;
		}

		public void setStatus(int status) {
			this.status = status;
		}

		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getText() {
			return text;
		}
		public void setText(String text) {
			this.text = text;
		}
		public String getSelected() {
			return selected;
		}
		public void setSelected(String selected) {
			this.selected = selected;
		}
	}
	
	public String readDataGridData() {
		System.out.println("--------data grid-------");
		JSONObject row = new JSONObject();
		JSONArray rowList = new JSONArray();
		try {
			for (int i = 0; i < 2; i++){
				row.put("productid", "FI-SW-01");
				row.put("productname", "Koi");
				row.put("unitcost", "10.00");
				row.put("status", "P");
				row.put("listprice", "36.50");
				row.put("attr1", "Large");
				row.put("itemid", "EST-1");
				rowList.put(row);
			}
			rows = rowList.toString();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		List<ProddductVO> list = new ArrayList<ProductVO>();
//		Map<String, Object> jsonMap = new HashMap<String, Object>(); 
//		ProductVO product = new ProductVO("EST-1","Koi",10.00,36.50,"Large","P","");
//		list.add(product);
//		product = new ProductVO("EST-10","Dalmation",12.00,18.50,"Spotted Adult Female","P","");
//		list.add(product);
//		product = new ProductVO("EST-11","Rattlesnake",12.00,38.50,"Venomless","P","");
//		list.add(product);
//		jsonMap.put("total", list.size());
//		jsonMap.put("rows",  list);  
//		result = JSONObject.fromObject(jsonMap);
		System.out.println("--------DONE-------");
		return SUCCESS;
	}
	
	public String sendDataGridData() {
		System.out.println("--------send data grid-------");
		System.out.println(rowList.size());
		return SUCCESS;
	}
	
	public String readComboBoxData() {
		cbxArray = new ArrayList<ComboBoxData>();
		
		ComboBoxData item = new ComboBoxData(1,"Java","true",1);
		cbxArray.add(item);
		item = new ComboBoxData(2,"C#","",0);
		cbxArray.add(item);
		
		return SUCCESS;
	}
	
	public String readJSON() {
		System.out.println("getJSON Method Call Before");
		
		data =  new ArrayList<Report>();	
		Report obj = new Report();
		obj.setActive(false);
		obj.setColor("Green");
		obj.setDate("05-Sep-2013");
		obj.setId(1);
		obj.setName("Rajesh");
		this.data.add(obj);
		
		System.out.println("getJSON Method Call");
		System.out.println("Length of Data is "+data.size());

		try{
		for (int i = 0; i < data.size(); i++) {
			System.out.println("Color is " + data.get(i).getColor());
			System.out.println("Date  is " + data.get(i).getDate());
			System.out.println("ID is " + data.get(i).getId());
			System.out.println("Names is " + data.get(i).getName());
		}}catch(Exception e)
		{
			e.printStackTrace();
		}
		return SUCCESS;
	}

	public String writeJSON() {
		try {
			System.out.println(data.size());

			for (int i = 0; i < data.size(); i++) {
				System.out.println("Data  " + data.get(i).getColor() +"-"+ data.get(i).getDate() +"-"+ data.get(i).getId()+"-"+ data.get(i).getName());
			}

			System.out.println("Execute Method");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SUCCESS;
	}

	public List<Report> getData() {
		System.out.println("Getter Call");
		return data;
	}

	public void setData(List<Report> data) {
		System.out.println("Setter Call Flow");
		this.data = data;
	}

	public List<ComboBoxData> getCbxArray() {
		return cbxArray;
	}

	public void setCbxArray(List<ComboBoxData> cbxArray) {
		this.cbxArray = cbxArray;
	}

	public JSONObject getResult() {
		return result;
	}

	public void setResult(JSONObject result) {
		this.result = result;
	}

	public List<ProductVO> getRowList() {
		return rowList;
	}

	public void setRowList(List<ProductVO> rowList) {
		this.rowList = rowList;
	}

	public String getRows() {
		return rows;
	}

	public void setRows(String rows) {
		this.rows = rows;
	}
	
}